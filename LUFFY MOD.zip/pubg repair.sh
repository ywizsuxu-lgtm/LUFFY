#!/system/bin/sh

# ============================================================
#    ██████╗ ██████╗ ███╗   ███╗ ██████╗ ██████╗ 
#    ██╔══██╗██╔══██╗████╗ ████║██╔═══██╗██╔══██╗
#    ██████╔╔╝██████╔██╔████╔██║██║   ██║██║  ██║
#    ██╔══██ ██╔═══╝ ██║╚██╔╝██║██║   ██║██║  ██║
#    ██║  ██║██║     ██║ ╚═╝ ██║╚██████╔╝██████╔╝
#    ╚═╝  ╚═╝╚═╝     ╚═╝     ╚═╝ ╚═════╝ ╚═════╝ 
#             CLEANER ADVANCED v5.0
# ============================================================
#    DEVELOPER: @LIB_hook
#    AUTHOR: Вот лидер тайного сайта.
#    VERSION: 5.0 ULTIMATE
# ============================================================

# Colors
R="\033[91m"
G="\033[92m"
Y="\033[93m"
B="\033[94m"
P="\033[95m"
C="\033[96m"
W="\033[97m"
N="\033[0m"

# ============================================================
#                   BANNER
# ============================================================
clear
echo -e "${P}"
echo "╔════════════════════════════════════════════════════════════╗"
echo "║     ██████╗ ██████╗ ███╗   ███╗ ██████╗ ██████╗           ║"
echo "║     ██╔══██╗██╔══██╗████╗ ████║██╔═══██╗██╔══██╗          ║"
echo "║     ██████╔╔╝██████╔██╔████╔██║██║   ██║██║  ██║          ║"
echo "║     ██╔══██ ██╔═══╝ ██║╚██╔╝██║██║   ██║██║  ██║          ║"
echo "║     ██║  ██║██║     ██║ ╚═╝ ██║╚██████╔╝██████╔╝          ║"
echo "║     ╚═╝  ╚═╝╚═╝     ╚═╝     ╚═╝ ╚═════╝ ╚═════╝           ║"
echo "╠════════════════════════════════════════════════════════════╣"
echo -e "║  ${C}DEVELOPER${P}: ${G}@LIB_hook${P}                                          ║"
echo -e "║  ${C}AUTHOR${P}:   ${Y}Вот лидер тайного сайта.${P}                            ║"
echo -e "║  ${C}VERSION${P}:  ${B}5.0 ULTIMATE${P}                                        ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo -e "${N}"

# ============================================================
#                   CONFIGURATION
# ============================================================
VERSION="5.0"
AUTHOR="@LIB_hook"
LOG_FILE="/data/local/tmp/r3p_cleaner.log"
START_TIME=$(date +%s)

# Package names
PACKAGES=(
    "com.tencent.ig"
    "com.pubg.krmobile"
    "com.vng.pubgmobile"
    "com.rekoo.pubgm"
    "com.tencent.iglite"
    "com.pubg.imobile"
    "com.tencent.tmgp.pubgm"
    "com.tencent.tmgp.pubgmhd"
    "com.tencent.pubgmhd"
    "com.tencent.pubg"
    "com.pubg.newstate"
    "com.pubg.pubgmg"
    "com.pubg.bgmim"
    "com.pubg.bgmia"
    "com.pubg.bgmih"
    "com.pubg.bgmij"
)

# ============================================================
#                   FUNCTIONS
# ============================================================

# Print with color
print_color() {
    echo -e "${2}${1}${N}"
}

# Print status
print_status() {
    echo -e "${G}[✓]${N} ${1}"
}

print_error() {
    echo -e "${R}[✗]${N} ${1}"
}

print_info() {
    echo -e "${C}[ℹ]${N} ${1}"
}

print_warning() {
    echo -e "${Y}[⚠]${N} ${1}"
}

print_progress() {
    echo -e "${P}[+]${N} ${1}"
}

# Check if running as root
check_root() {
    print_progress "Checking root access..."
    if [ "$(id -u)" != "0" ]; then
        print_error "Root access required!"
        exit 1
    else
        print_status "Root access granted"
    fi
}

# Check if package exists
package_exists() {
    pm list packages | grep -q "$1"
    return $?
}

# Safe remove with error handling
safe_rm() {
    if [ -e "$1" ]; then
        rm -rf "$1" 2>/dev/null
        if [ $? -eq 0 ]; then
            echo "$(date): Removed $1" >> "$LOG_FILE"
            return 0
        else
            echo "$(date): Failed to remove $1" >> "$LOG_FILE"
            return 1
        fi
    fi
    return 0
}

# Safe chmod with error handling
safe_chmod() {
    if [ -e "$2" ]; then
        chmod "$1" "$2" 2>/dev/null
        if [ $? -eq 0 ]; then
            echo "$(date): Changed permissions $1 on $2" >> "$LOG_FILE"
            return 0
        fi
    fi
    return 1
}

# Clean specific package
clean_package() {
    local pkg="$1"
    local count=0
    
    print_progress "Cleaning $pkg..."
    
    # Check if package exists
    if ! package_exists "$pkg"; then
        print_warning "Package $pkg not found, skipping"
        return
    fi
    
    # Define paths
    local paths=(
        "/data/data/$pkg/files"
        "/data/data/$pkg/ALSHEIKH"
        "/data/data/$pkg/app_crashrecord"
        "/data/data/$pkg/cache"
        "/data/data/$pkg/files/ano_tmp/tssmua.zip"
        "/data/data/$pkg/files/ano_tmp/config3.xml"
        "/data/data/$pkg/files/ano_tmp/comm.dat"
        "/data/data/$pkg/files/.i\.e"
        "/data/data/$pkg/files/.ac"
        "/data/data/$pkg/files/.se"
        "/data/data/$pkg/files/.vc"
        "/data/data/$pkg/files/.gameguardian"
        "/data/data/$pkg/files/.gg"
        "/data/data/$pkg/files/.lgl"
        "/data/data/$pkg/files/.mod"
        "/data/data/$pkg/files/.cheat"
        "/data/data/$pkg/files/.hack"
        "/data/data/$pkg/files/__handroid*"
        "/data/data/$pkg/files/handroid*"
        "/data/data/$pkg/shared_prefs/preference_ano_tmp.xml"
        "/data/data/$pkg/shared_prefs/device.xml"
        "/data/data/$pkg/shared_prefs/device_id.xml"
        "/data/data/$pkg/shared_prefs/va.device.xml"
        "/data/data/$pkg/shared_prefs/virtual.xml"
    )
    
    # Remove paths
    for path in "${paths[@]}"; do
        if safe_rm "$path"; then
            ((count++))
        fi
    done
    
    # Handle SDCard paths
    local sdcard_paths=(
        "/sdcard/Android/data/$pkg/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_*"
        "/sdcard/Android/data/$pkg/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs"
        "/sdcard/Android/data/$pkg/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Profiling"
        "/sdcard/Android/data/$pkg/cache"
    )
    
    for path in "${sdcard_paths[@]}"; do
        safe_rm "$path"
    done
    
    # Fix permissions
    local perm_paths=(
        "/data/data/$pkg/files/ano_tmp"
        "/data/media/0/Android/data/$pkg/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks"
        "/data/media/0/Android/data/$pkg/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini"
        "/data/media/0/Android/data/$pkg/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData"
        "/data/data/$pkg/databases"
    )
    
    for path in "${perm_paths[@]}"; do
        safe_chmod 755 "$path"
    done
    
    print_status "Cleaned $count items from $pkg"
}

# Clean all packages
clean_all() {
    local total=0
    local found=0
    
    print_info "Starting advanced cleaning process..."
    echo "$(date): Cleaner started" > "$LOG_FILE"
    
    for pkg in "${PACKAGES[@]}"; do
        if package_exists "$pkg"; then
            ((found++))
            clean_package "$pkg"
            ((total++))
            sleep 0.1
        fi
    done
    
    if [ $found -eq 0 ]; then
        print_warning "No PUBG packages found"
    else
        print_status "Cleaned $total packages"
    fi
}

# Clean specific directories
clean_directories() {
    print_progress "Cleaning additional directories..."
    
    local dirs=(
        "/data/data/*/files/ano_tmp"
        "/data/data/*/app_crashrecord"
        "/data/data/*/cache"
        "/sdcard/Android/data/*/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_*"
        "/sdcard/Android/data/*/cache"
    )
    
    for dir in "${dirs[@]}"; do
        safe_rm "$dir"
    done
}

# Fix permissions
fix_permissions() {
    print_progress "Fixing permissions..."
    
    local perm_dirs=(
        "/data/data/*/files/ano_tmp"
        "/data/data/*/databases"
        "/sdcard/Android/data/*/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks"
    )
    
    for dir in "${perm_dirs[@]}"; do
        for d in $dir; do
            if [ -d "$d" ]; then
                safe_chmod 755 "$d"
            fi
        done
    done
}

# Show statistics
show_stats() {
    END_TIME=$(date +%s)
    DURATION=$((END_TIME - START_TIME))
    
    echo -e "\n${C}════════════════════════════════════════════${N}"
    echo -e "${P}            CLEANING STATISTICS${N}"
    echo -e "${C}════════════════════════════════════════════${N}"
    echo -e "${G}Developer:${N} ${Y}@LIB_hook${N}"
    echo -e "${G}Author:${N}    ${Y}Вот лидер тайного сайта.${N}"
    echo -e "${G}Version:${N}    ${B}5.0 ULTIMATE${N}"
    echo -e "${G}Duration:${N}   ${W}${DURATION}s${N}"
    echo -e "${G}Log file:${N}   ${W}$LOG_FILE${N}"
    echo -e "${C}════════════════════════════════════════════${N}"
}

# Menu
show_menu() {
    echo -e "\n${C}════════════════════════════════════════════${N}"
    echo -e "${P}              OPTIONS MENU${N}"
    echo -e "${C}════════════════════════════════════════════${N}"
    echo -e "${G}[1]${N} Clean all packages"
    echo -e "${G}[2]${N} Clean specific package"
    echo -e "${G}[3]${N} Fix permissions only"
    echo -e "${G}[4]${N} Clean directories only"
    echo -e "${G}[5]${N} Complete cleaning (all)"
    echo -e "${G}[6]${N} Show statistics"
    echo -e "${G}[7]${N} Exit"
    echo -e "${C}════════════════════════════════════════════${N}"
    echo -n -e "${Y}Choose option [1-7]: ${N}"
    read choice
    
    case $choice in
        1) clean_all ;;
        2) 
            echo -n -e "${Y}Enter package name: ${N}"
            read pkg
            clean_package "$pkg"
            ;;
        3) fix_permissions ;;
        4) clean_directories ;;
        5) 
            clean_all
            clean_directories
            fix_permissions
            ;;
        6) show_stats ;;
        7) exit 0 ;;
        *) print_error "Invalid option" ;;
    esac
}

# ============================================================
#                   MAIN EXECUTION
# ============================================================

# Check root
check_root

# Create log directory
mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null

# Check arguments
if [ "$1" = "-a" ] || [ "$1" = "--all" ]; then
    # Auto mode
    clean_all
    clean_directories
    fix_permissions
    show_stats
elif [ "$1" = "-p" ] && [ -n "$2" ]; then
    # Package mode
    clean_package "$2"
    fix_permissions
    show_stats
elif [ "$1" = "-h" ] || [ "$1" = "--help" ]; then
    echo "Usage: $0 [OPTION]"
    echo "  -a, --all     Clean all packages"
    echo "  -p PKG        Clean specific package"
    echo "  -h, --help    Show this help"
    echo "  (no option)   Show interactive menu"
else
    # Interactive mode
    while true; do
        show_menu
        echo -n -e "\n${Y}Press enter to continue...${N}"
        read
        clear
    done
fi

# ============================================================
#                   END
# ============================================================
echo -e "${G}"
echo "╔════════════════════════════════════════════════════════════╗"
echo "║              CLEANING COMPLETED SUCCESSFULLY              ║"
echo "║                    @LIB_hook - ВОТ ЛИДЕР                  ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo -e "${N}"

exit 0